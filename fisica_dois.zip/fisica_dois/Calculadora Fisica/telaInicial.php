<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=], initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Calculadora</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
        <style>
            div{
                text-align: center;
            }
        </style>
    </head>

    <body>
        <section class="content">
                <div class="contact">
                    <h3>Quais informações você possui?</h3>

                    <form class="form" action="calculadora.php" method="post">
                    
                    <label>Calor Sensivel[J]</label>
                        <input type="text" name="qtdCalor"></br>

                    <label>Massa [Kg]</label>
                        <input type="text" name="massa"></br>

                    <label>Calor Especifico [J/Kg]</label>
                        <input type="text" name="especifico"></br>

                    <label>Variação de Temperatura [K]</label></br>

                        <label>Temperatura Inicial</label>
                                <input type="text" name="tempInicial"></br>
                                
                        <label>Temperatura Final</label>
                                <input type="text" name="tempFinal"></br>           
                        
                            <input type="submit" value="Calcular">
                </div>
                <div>
                    </br>
                    <input type="button" value="Voltar" onclick="history.back()"/> 
                </div>
            </section>
    </body>
</html>

