<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <style>
        div{
            text-align: center;
        }
    </style>
</head>
<body>
    <div>
    <?php

$qtdCalor = (double)$_POST["qtdCalor"];
$massa = (double)$_POST["massa"];
$especifico = (double)$_POST["especifico"];
$tempFinal = (double)$_POST["tempFinal"];
$tempInicial = (double)$_POST["tempInicial"];
$resultado = 0;
$varTemp = 0;

    if(empty($massa) && empty($especifico) && !empty($tempFinal) && !empty($tempInicial) && !empty($qtdCalor)){
        $resultado = $qtdCalor/($tempFinal-$tempInicial);
        
        echo "Capacidade Térmica: ", $resultado, "kCal/°C";
    }

    elseif(!empty($massa) && !empty($especifico) && !empty($tempFinal) && !empty($tempInicial)){

        $varTemp = $tempFinal-$tempInicial;
        echo "Variação da temperatura ", $varTemp, "K \n";

        $qtdCalor = $massa * ($especifico * $varTemp);
        
        echo "Calor sensivel: ", $qtdCalor, "J\n";

        

        $resultado = $qtdCalor/($tempFinal-$tempInicial);
        
        echo "Capacidade Térmica: ", $resultado, "kCal/°C";
    }

    elseif(empty($especifico)){
        $varTemp = $tempFinal-$tempInicial;
        echo "Variação da temperatura ", $varTemp, "\n";

        $especifico = $qtdCalor * ($massa * $varTemp);
        echo "especifico ", $especifico, "J/Kg \n";

        $resultado = $qtdCalor/($tempFinal-$tempInicial);

        echo "Capacidade Térmica: ", $resultado, "kCal/°C";
    }

    elseif(empty($tempFinal)){

        $tempFinal = ($massa * $qtdCalor) * $tempInicial;

        echo "tempFinal ", $qtdCalor, "K \n";

        $resultado = $qtdCalor/($tempFinal-$tempInicial);
        
        echo "Capacidade Térmica: ", $resultado, "kCal/°C";
    }
?>
    </div>
    
</body>
</html>