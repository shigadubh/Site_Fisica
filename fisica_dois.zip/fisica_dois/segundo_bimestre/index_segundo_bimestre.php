<!DOCTYPE html>
<html lang="br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Segundo Bimestre</title>
	<style>
		h2{
			text-align: center;
		}
		label{
			text-align: center;
		}
		div{
			text-align: center;
		}
	</style>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
<body>
<br>
<h2>Transformação Adiabática</h2>
<br>
	<form action="/fisica_dois/segundo_bimestre/result.php"
		method="post">
		
		<div>
		<label>Q (Calor)</label>
		<input type="text" name="box_calor"
			value=""/>

		<label>τ (Trabalho)</label>
		<input type="text" name="box_trabalho"
			value=""/>

		<label>ΔU (Variação de Energia Interna)</label>
		<input type="text" name="box_variacao_energia_interna"
			value=""/>
		<br>
		<br>
			<input type="submit" name="salvar"
			value="Salvar"/>
		</div>
	</form>
	<br>
	<div>
	<input type="button" value="Voltar" onclick="history.back()"/> 
	</div>
</body>
</html>

