<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        div{
            text-align: center;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
<body>
    <div>
    <?php
    $calor = $_POST['box_calor'];
    $trabalho = $_POST['box_trabalho'];
    $variacao_energia_interna = $_POST['box_variacao_energia_interna'];

    if($variacao_energia_interna == ""){
        $variacao_energia_interna = $calor - $trabalho;
        echo $calor." = ".$trabalho." + ΔU"; echo "<br>";
        echo "ΔU = ".$calor." - ".$trabalho; echo "<br>";
        echo "O Valor de ΔU (Variação de Energia Interna) = ".$variacao_energia_interna; echo "<br>";
        echo "<br>";
    }

    if($trabalho == ""){
        $trabalho = $calor - $variacao_energia_interna;
        echo $calor." = ".$variacao_energia_interna." + τ"; echo "<br>";
        echo "τ = ".$calor." - ".$variacao_energia_interna; echo "<br>";
        echo "O Valor de τ (Trabalho) = ".$trabalho; echo "<br>";
        echo "<br>";      
    }

    if($calor == ""){ 
        $calor = $trabalho + $variacao_energia_interna;
        echo "Q = ".$trabalho." + ".$variacao_energia_interna; echo "<br>";
        echo "O Valor de Q (Calor) = ".$calor; echo "<br>";
        echo "<br>";
        }

    if($calor == $trabalho){
        echo "Transformação Isotérmica";
    }

    if($calor == $variacao_energia_interna){
        echo "Transformação Isovolumétrica";
    }

    if($trabalho == -$variacao_energia_interna){
        echo "Transformação Adiabática";
    }
    ?>
    <div>
</body>
</html>